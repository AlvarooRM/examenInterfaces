console.log("Hola mundo...");

function abrirBorrar() {
    document.getElementById('borrar').style.display = 'flex';
}

function cerrarBorrar() {
    document.getElementById('borrar').style.display = 'none';

}

function nuevoCoche() {
    document.getElementById('nuevoCoche').style.display = 'flex';
}

function cerrarCoche() {
    document.getElementById('nuevoCoche').style.display = 'none';
}