# Examen Diciembre 2023
Diseño de Interfaces Web
### Criterios de evaluación
1. Similitud con el diseño planteado.
2. Funcionalidad del diseño segun lo planteado en el ejercicio.
3. Simplicidad del código.
4. Uso correcto del HTML y estructura del DOM. Diseño correcto del formulario.
5. Uso correcto de las clases, selectores y propiedades CSS.
6. Uso correcto de SCSS.
7. Uso adecuado de JS para la conmutación de las ventanas
8. Cumplimiento de todas las especificaciones del examen
10. Organización del proyecto.
11. Seguir correctamente las instrucciones del examen

